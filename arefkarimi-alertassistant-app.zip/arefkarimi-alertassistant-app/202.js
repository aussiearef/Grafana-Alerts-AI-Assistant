"use strict";(self.webpackChunkarefkarimi_alertassistant_app=self.webpackChunkarefkarimi_alertassistant_app||[]).push([[202],{202:(a,e,s)=>{s.r(e),s.d(e,{default:()=>l});var n=s(959),i=s.n(n),t=s(89),r=s(7);const l=({plugin:a})=>{const e=(0,r.useStyles2)(u),{enabled:s,pinned:n}=a.meta;return i().createElement(r.FieldSet,{label:"Plugin Configuration"},i().createElement("div",{className:e.message},"This plugin uses Grafana’s internal APIs and LLM plugin for functionality. No additional configuration is required."))},u=a=>({message:t.css`
    margin-top: ${a.spacing(2)};
    color: ${a.colors.text.primary};
  `})}}]);
//# sourceMappingURL=202.js.map?_cache=84d7a449b59e71bfbcdc