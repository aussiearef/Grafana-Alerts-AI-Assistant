"use strict";(self.webpackChunkarefkarimi_alertassistant_app=self.webpackChunkarefkarimi_alertassistant_app||[]).push([[466],{466:(e,t,n)=>{n.r(t),n.d(t,{default:()=>d});var r=n(959),a=n.n(r),l=n(531),o=n(7),s=n(89);function i(e,t,n,r,a,l,o){try{var s=e[l](o),i=s.value}catch(e){return void n(e)}s.done?t(i):Promise.resolve(i).then(r,a)}function c(e){return function(){var t=this,n=arguments;return new Promise((function(r,a){var l=e.apply(t,n);function o(e){i(l,r,a,o,s,"next",e)}function s(e){i(l,r,a,o,s,"throw",e)}o(void 0)}))}}const d=()=>{const[e,t]=(0,r.useState)([]),[n,i]=(0,r.useState)([]),[d,u]=(0,r.useState)(null),[m,g]=(0,r.useState)(null),[p,f]=(0,r.useState)(!1),[v,h]=(0,r.useState)(!1),[y,b]=(0,r.useState)(!1),E=(0,o.useTheme2)(),k=function(){var e=c((function*(){try{b(!0);const e=(yield(0,l.getBackendSrv)().get("/api/alertmanager/grafana/api/v2/alerts")).filter((e=>"active"===e.status.state)),n=yield(0,l.getBackendSrv)().get("/api/v1/provisioning/alert-rules");t(e),i(n)}catch(e){throw e}finally{b(!1)}}));return function(){return e.apply(this,arguments)}}();(0,r.useEffect)((()=>{k()}),[]);const w=e=>{var t,r,a,l;const o=null===(t=e.labels)||void 0===t?void 0:t.__alert_rule_uid__;if(!o)return"N/A";const s=n.find((e=>e.uid===o));if(!s)return"N/A";const i=s.condition,c=(null===(a=s.data.find((e=>e.refId===i)))||void 0===a||null===(r=a.model)||void 0===r?void 0:r.expr)||"A",d=s.data.find((e=>{var t;return e.refId===c&&(null===(t=e.model)||void 0===t?void 0:t.expr)}));return(null==d||null===(l=d.model)||void 0===l?void 0:l.expr)||"N/A"},$=function(){var e=c((function*(e,t){var r,a;g(t),u(null),h(!0);const o=e.labels.alertname,s=w(e),i=(null===(r=e.annotations)||void 0===r?void 0:r.__value_string__)||"N/A",c=(e=>{var t,r,a,l,o,s;const i=null===(t=e.labels)||void 0===t?void 0:t.__alert_rule_uid__;if(!i)return"unknown";const c=n.find((e=>e.uid===i));if(!c)return"unknown";const d=c.data.find((e=>{var t;return"threshold"===(null===(t=e.model)||void 0===t?void 0:t.type)})),u=null==d||null===(s=d.model)||void 0===s||null===(o=s.conditions)||void 0===o||null===(l=o[0])||void 0===l||null===(a=l.evaluator)||void 0===a||null===(r=a.params)||void 0===r?void 0:r[0];return void 0!==u?u.toString():"unknown"})(e),d=(null===(a=e.annotations)||void 0===a?void 0:a.summary)||"No summary provided",m=`You are a senior SRE. An alert was triggered in Grafana with the following details:\n\n- Alert Name: ${o}\n- Status: ${e.status.state}\n- Value: ${i}\n- Threshold: ${c}\n- PromQL Query: ${s}\n- Description: ${d}\n\nPlease classify the severity (Warning or Critical), suggest root cause(s), and remediation steps. Use ITIL terminology. Return JSON with keys: category, root_cause[], remediation[].`;try{var p,v,y;const e=null===(y=(yield(0,l.getBackendSrv)().post("/api/plugins/grafana-llm-app/resources/llm/v1/chat/completions",{model:"base",messages:[{role:"system",content:"You are a senior SRE."},{role:"user",content:m}]})).choices)||void 0===y||null===(v=y[0])||void 0===v||null===(p=v.message)||void 0===p?void 0:p.content;if(!e)throw new Error("No content in LLM response");const t="string"==typeof e?e.replace(/```json|```/g,"").trim():e,n="string"==typeof t?JSON.parse(t):t;u(n),f(!0)}catch(e){u({error:`Failed to get AI response: ${e.message||"Unknown error"}`}),f(!0)}g(null),h(!1)}));return function(t,n){return e.apply(this,arguments)}}();return a().createElement("div",null,a().createElement("h2",{className:s.css`
          font-size: 1.5rem;
          font-weight: 600;
          font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
          margin-bottom: ${E.spacing(2)};
          margin-top: ${E.spacing(2)};
          margin-left: ${E.spacing(1)};
        `},"Alert AI Assistant"),a().createElement(o.Stack,{direction:"row",justifyContent:"space-between",alignItems:"center"},a().createElement(o.Button,{className:s.css`
            font-size: 1.5 rem;
            font-weight: 200;
            font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
            margin-bottom: ${E.spacing(2)};
            margin-top: ${E.spacing(2)};
            margin-left: ${E.spacing(1)};
          `,onClick:k,disabled:y,icon:y?"sync":"repeat"},y?"Refreshing...":"Refresh")),v&&a().createElement("div",{style:{textAlign:"center",margin:"1rem 0"}},a().createElement(o.Spinner,null)," ",a().createElement("span",null,"Thinking...")),0===e.length?a().createElement("div",{className:s.css`
            text-align: center;
            font-style: italic;
            color: ${E.colors.text.secondary};
            padding: ${E.spacing(4)};
          `},"🎉 No alerts firing. All systems go!"):a().createElement("div",{className:s.css`
            background: ${E.colors.background.secondary};
            padding: ${E.spacing(2)};
            border-radius: ${E.shape.radius.default}px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
          `},a().createElement("table",{className:s.css`
              width: 100%;
              border-collapse: collapse;
              margin-top: ${E.spacing(1)};
              font-family: 'Segoe UI', sans-serif;
              font-size: 0.9rem;
              transition: background-color 0.2s ease;

              thead th {
                text-align: left;
                padding: 8px;
                background-color: ${E.colors.background.secondary};
                border-bottom: 2px solid ${E.colors.border.weak};
                font-weight: bold;
              }

              tbody td {
                padding: 8px;
                border-bottom: 1px solid ${E.colors.border.weak};
              }

              tbody tr:hover {
                background-color: ${E.colors.background.primary};
              }
            `},a().createElement("thead",null,a().createElement("tr",null,a().createElement("th",null,"Alert Name"),a().createElement("th",null,"Status"),a().createElement("th",null,"Query"),a().createElement("th",null,"Action"))),a().createElement("tbody",null,e.map(((e,t)=>{const r=n.find((t=>{var n;return t.uid===(null===(n=e.labels)||void 0===n?void 0:n.__alert_rule_uid__)})),l="DatasourceError"===e.labels.alertname?(null==r?void 0:r.title)||"Unknown Rule":e.labels.alertname;return a().createElement("tr",{key:t},a().createElement("td",null,l),a().createElement("td",null,a().createElement("span",{className:s.css`
                          background-color: ${"active"===e.status.state?E.colors.error.main:E.colors.success.main};
                          color: white;
                          padding: 2px 8px;
                          border-radius: 999px;
                          font-size: 0.75rem;
                        `},e.status.state.toUpperCase())),a().createElement("td",null,w(e)),a().createElement("td",null,a().createElement(o.Button,{className:s.css`
                          font-size: 1.5 rem;
                          font-weight: 200;
                          font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
                          margin-bottom: ${E.spacing(2)};
                          margin-top: ${E.spacing(2)};
                          margin-left: ${E.spacing(1)};
                        `,size:"sm",onClick:()=>$(e,t),disabled:m===t,icon:m===t?"sync":"search"},m===t?"Investigating...":"Investigate")))}))))),a().createElement(o.Modal,{title:"Investigation Summary",isOpen:p,onDismiss:()=>f(!1)},d?"error"in d?a().createElement("pre",{style:{color:"red"}},d.error):a().createElement("div",null,a().createElement("p",{className:s.css`
                  font-family: Calibri, serif;
                  font-weight: bold;
                  font-size: 1.2rem;
                  color: ${"Critical"===d.category?"red":"orange"};
                `},"Category: ",d.category),a().createElement("table",{className:s.css`
                  width: 100%;
                  margin-top: ${E.spacing(1)};
                  border-collapse: collapse;

                  th {
                    font-family: Georgia, serif;
                    font-weight: bold;
                    font-size: 1.05rem;
                    padding-bottom: 4px;
                    border-bottom: 1px solid ${E.colors.border.weak};
                    text-align: left;
                  }

                  td {
                    vertical-align: top;
                    padding: 6px 8px 6px 0;
                    font-family: system-ui, sans-serif;
                  }
                `},a().createElement("thead",null,a().createElement("tr",null,a().createElement("th",null,"Root Causes"),a().createElement("th",null,"Remediation"))),a().createElement("tbody",null,Array.from({length:Math.max(d.root_cause.length,d.remediation.length)}).map(((e,t)=>a().createElement("tr",{key:t},a().createElement("td",null,d.root_cause[t]||""),a().createElement("td",null,d.remediation[t]||""))))))):null))}}}]);
//# sourceMappingURL=466.js.map?_cache=53d32b3f4710cf1adc42